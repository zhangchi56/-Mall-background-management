<template>
  <div class="index">
    <el-container class="main-el-container">
      <!-- 图片头部搜素区域 -->
      <el-header class="el-header border-bottom">
        <div class="d-flex">
          <div class="el-header-right mr-auto">
            <el-select
              v-model="searchForm.order"
              class="el-select mr-2"
              placeholder="请选择活动区域"
              style="width:150px;"
              size="medium"
            >
              <el-option label="降序" value="desc"></el-option>
              <el-option label="升序" value="asc"></el-option>
            </el-select>
            <el-input
              class="mr-2"
              size="medium"
              style="width:150px;"
              placeholder="输入图片名称"
              v-model="searchForm.keyword"
            ></el-input>
            <el-button type="primary">搜索</el-button>
          </div>

          <div class="el-header-left">
            <el-button type="primary" size="medium" @click="confirmAlbumModel">创建相册</el-button>
            <el-button type="primary" size="medium">上传图片</el-button>
          </div>
        </div>
      </el-header>

      <!-- 主要部分 -->
      <el-container>

        <!-- 侧边栏相册 -->
        <el-aside width="200px" class="main-el-aside">
          <div class="container-el-aside">
            <ul class="list-group">
              <li
                v-for="(item, index) in albums"
                :key="index"
                :class="{'active activeAlbums' : index === ablumsIndex}"
                class="list-group-item list-group-item-action d-flex align-items-center"
                style="cursor:pointer;"
                @click="albumChange(index)"
              >
                <span class="mr-auto">{{item.name}}</span>
                <span>
                  <el-dropdown>
                    <el-button size="mini" type="primary" class="album-el-button">
                      {{item.num}}
                      <i class="el-icon-arrow-down el-icon--right"></i>
                    </el-button>
                    <!-- 修改删除功能 -->
                    <el-dropdown-menu slot="dropdown">
                      <el-dropdown-item @click.stop.native="openAlbumModel({item,index})">修改</el-dropdown-item>
                      <el-dropdown-item @click.stop.native="albumDel(index)">删除</el-dropdown-item>
                    </el-dropdown-menu>
                  </el-dropdown>
                </span>
              </li>
            </ul>
          </div>
        </el-aside>

        <!-- 主内容 -->
        <el-container>
          <el-main class="el-main">主要部分</el-main>
        </el-container>
      </el-container>
      <el-footer>底部</el-footer>
    </el-container>

    <!-- 修改|创建相册模态框 -->
    <el-dialog title="修改相册" :visible.sync="albumModel">
      <el-form ref="form" :model="albumForm" label-width="80px">
        <el-form-item label="相册名称">
          <el-input v-model="albumForm.name" size="medium" placeholder="请输入相册名称"></el-input>
        </el-form-item>
        <el-form-item label="相册排序">
          <el-input-number v-model="albumForm.order" size="medium" :min="0"></el-input-number>
        </el-form-item>
      </el-form>

      <div slot="footer" class="dialog-footer">
        <el-button @click="albumModel = false">取 消</el-button>
        <el-button type="primary" @click="confirmAlbumModel">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script type="text/javascript">
export default {
  data() {
    return {
      searchForm: {
        order: "",
        keyword: ""
      },
      albums: [],
      ablumsIndex: 0,
      albumModel: false,
      albumEditIndex: -1,
      albumForm: {
        name: "",
        order: 0,
        index: Number
      },
    };
  },
  components: {},
  created() {
    //初始化相册目录
    this.__init();
  },
  mounted() {
    console.log(this.albumForm.name);
  },
  updated() {
    console.log("数据更新" + this.albumForm.name);
  },
  destroyed() {
    console.log("销毁" + this.albumForm.name);
  },
  methods: {
    //初始化相册目录方法
    __init() {
      for (var i = 0; i < 20; i++) {
        this.albums.push({
          name: "相册" + i,
          order: 0,
          num: Math.floor(Math.random() * 100)
        });
      }
    },
    //切换相册
    albumChange(index) {
      this.ablumsIndex = index;
    },
    //打开相册修改或者创建框
    openAlbumModel(obj) {
      //修改表单
      if (obj) {
        let { item, index } = obj;
        this.albumForm.name = item.name;
        this.albumForm.order = item.order;
        this.albumEditIndex = index;
        // console.log("albumForm" + this.albumForm.name + "+++++++" + item.name);

        //打开模态框
        return (this.albumModel = true);
      }

      //创建表单
      this.albumForm = {
        name: "",
        order: 0
      };
      this.albumEditIndex = -1;
      this.albumModel = true;
    },

    //修改相册
    albumEdit() {
      this.albums[this.albumEditIndex].name = this.albumForm.name;
      this.albums[this.albumEditIndex].order = this.albumForm.order;
      // console.log(this.albums[this.albumEditIndex].name);

      // this.$set(this.albums[this.albumEditIndex],'name',this.albumForm.name)
      // this.$set(this.albums[this.albumEditIndex].'order',this.albumForm.order)

      console.log(this.albums);
    },
    //创建表单
    albumAdd() {
      // this.albums[this.albumEditIndex].name = this.name;
      // this.albums[this.albumEditIndex].order = this.order;
    },
    //删除相册
    albumDel(index) {
      this.albums.splice(index, 1);
      this.$confirm("此操作将永久删除该文件, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          this.$message({
            type: "success",
            message: "删除成功!"
          });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    },

    // 点击确定修改或者创建相册
    confirmAlbumModel() {
      //判断是否是修改表单    >1创建表单
      if (this.albumEditIndex > -1) {
        this.albumEdit();
        return (this.albumModel = false);
      }
      // this.albums.unshift({name:this.albumForm.name})
    },
    // watch: {
    //   albums(val){
    //     this.value = this.albums
    //   }
      
    // },
  }
};
</script>

<style scoped>
.el-header,
.el-footer {
  background-color: #b3c0d1;
  /* color: #333; */
  text-align: center;
  /* line-height: 60px; */
}
.main-el-container {
  position: absolute;
  top: 56px;
  bottom: 0;
  left: 0;
  right: 0;
}
.main-el-aside {
  position: absolute;
  top: 60px;
  bottom: 60px;
  left: 0;
  right: 200px;
  line-height: 20px;
}
.el-main {
  position: absolute;
  top: 60px;
  bottom: 60px;
  left: 200px;
  right: 0;
}
.el-header {
  background-color: #f8f9fa;
  /* display: flex; */
  /* justify-content: space-between; */
}

.container-el-aside .list-group-item:first-child {
  border-top-left-radius: 0;
  border-top-right-radius: 0;
  border-top: 0;
}
.activeAlbums {
  color: #409eff !important;
  background-color: white !important;
  border-color: #c2e7b0 !important;
}
</style>
