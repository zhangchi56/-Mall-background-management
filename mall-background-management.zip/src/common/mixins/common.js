export default{
  filters: {
    numToString(value){
      return value.toString()
    }
  }
};
